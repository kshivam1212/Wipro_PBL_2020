package p1;

public class Assign {
	private String x;

	public String getX() {
		return x;
	}

	public void setX(String x) {
		this.x = x;
	}



}
