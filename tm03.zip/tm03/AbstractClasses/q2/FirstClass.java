

public class FirstClass extends Compartment{
	public String notice() {
		return "This is First class.";
	}
}
