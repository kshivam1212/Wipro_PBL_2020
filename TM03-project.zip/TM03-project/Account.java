package com.shivam.wipro.pjp.tm03.proj;

public abstract class Account {
	double interestRate;
	double amount;
	
	abstract double calculateInterest();

}