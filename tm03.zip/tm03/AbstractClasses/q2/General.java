

public class General extends Compartment{
	public String notice()
	{
		return "This is general Compartment";
	}
}
