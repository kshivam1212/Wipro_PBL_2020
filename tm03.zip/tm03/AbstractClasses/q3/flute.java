

public class flute extends Instrument{
	public String play()
	{
		return "Flute is playing toot toot toot toot";
	}
}
