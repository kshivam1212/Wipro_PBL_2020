package p1;

public class Bean {
	private String u;
	private String p;
	public String getU() {
		return u;
	}
	public void setU(String u) {
		this.u = u;
	}
	public String getP() {
		return p;
	}
	public void setP(String p) {
		this.p = p;
	}

}
