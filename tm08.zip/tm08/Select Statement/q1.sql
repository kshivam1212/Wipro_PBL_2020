/*  Determine the structure of the DEPARTMENTS table and its contents. */

DESCRIBE DEPARTMENTS;