

import com.shivam.wipro.pjp.tm03.Interfaces.q2.music.Playable;

public class Saxophone implements Playable{
	public void play()
	{
		System.out.println("Saxophone playing");
	}
}
