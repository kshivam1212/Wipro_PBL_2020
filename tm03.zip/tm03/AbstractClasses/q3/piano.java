

public class piano extends Instrument{
	public String play()
	{	
		return "Piano is playing tan tan tan tan";
	}
}
