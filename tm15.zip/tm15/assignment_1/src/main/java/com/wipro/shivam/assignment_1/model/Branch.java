

public class Branch {
	
	private String branchName;

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	
	public Branch(String branchName) {
		this.branchName= branchName;
	}

}
