package com.wipro.sample;

public class Triangle extends Shape {
	public void draw(){
		System.out.println("Drawing Triangle");
	}  
}