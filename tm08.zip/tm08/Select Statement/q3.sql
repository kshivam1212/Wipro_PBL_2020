/*Create a query to display all unique job IDs from the EMPLOYEES table.*/
SELECT DISTINCT
    job_id
FROM
    employees;