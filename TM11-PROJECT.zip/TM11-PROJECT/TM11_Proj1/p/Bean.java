package p;

public class Bean {
	private String itemid;
	private String itemname;
	private String uname;
	private String email;
	private String bidamount;
	private String autoi;
	public String getItemid() {
		return itemid;
	}
	public void setItemid(String itemid) {
		this.itemid = itemid;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBidamount() {
		return bidamount;
	}
	public void setBidamount(String bidamount) {
		this.bidamount = bidamount;
	}
	public String getAutoi() {
		return autoi;
	}
	public void setAutoi(String autoi) {
		this.autoi = autoi;
	}
	

}
