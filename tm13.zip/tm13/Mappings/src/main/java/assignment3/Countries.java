package assignment3;

import java.util.HashMap;
import java.util.Map;
public class Countries {
	Map<String, String> m=new HashMap<String, String>();
	

	public Map<String, String> getM() {
		return m;
	}

	public void setM(Map<String, String> m) {
		this.m = m;
	}

}
