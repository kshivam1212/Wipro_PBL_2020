package com.wipro.sample;

public class Parallelogram extends Shape {
	public void draw(){
		System.out.println("Drawing Parallelogram");
	}
}