package com.foodcart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodcartApplication {

	public static void main(String[] args) {
		System.out.println("sd");
		SpringApplication.run(FoodcartApplication.class, args);
	}

}
