package com.subho.wipro.pjp.tm03.Packages.q2.com.automobile.fourwheeler;

import com.subho.wipro.pjp.tm03.Packages.q2.com.automobile.Vehicle;

public class honda extends Vehicle{
	public String getModelNumber()
	{
		return "Honda1003n";
	}
	public String getRegistrationNumber()
	{
		return "WB00192";
	}
	public String getOwnerName()
	{
		return "jones";
	}
	public int getSpeed()
	{
		return 92;
	}
	public void cdplayer()
	{
		System.out.println("cpplayer playing");
	}
}
