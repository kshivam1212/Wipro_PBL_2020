

public abstract class Vehicle {
	public abstract String getModelNumber();
	public abstract String getRegistrationNumber();
	public abstract String getOwnerName();
}
