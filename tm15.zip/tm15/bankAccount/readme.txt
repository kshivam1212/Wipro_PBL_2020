this is a spring boot rest api project 
bank and customer   