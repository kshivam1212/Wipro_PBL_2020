package com.wipro.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wipro.bean.Student;

public class Main {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext factory=new ClassPathXmlApplicationContext("beans.xml");
        
		Student student = (Student)factory.getBean("StudentBean");
		student.show();
	}
}