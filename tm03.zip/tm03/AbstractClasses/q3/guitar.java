

public class guitar extends Instrument{
	public String play()
	{
		return "Guitar is playing tin tin tin";
	}
}
