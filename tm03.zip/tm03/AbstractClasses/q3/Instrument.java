

public abstract class Instrument {
	abstract public String play();
}
