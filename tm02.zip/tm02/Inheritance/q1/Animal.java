

public class Animal {
	
	void eat() {
		System.out.println("Animal eats");
	}
	
	void sleep() {
		System.out.println("Animal sleeps");
	}
}
