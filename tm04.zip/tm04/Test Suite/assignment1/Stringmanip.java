

public class Stringmanip {
		String datum; 
		
		public Stringmanip(String datum) {
			this.datum = datum; 
		}
		
		public String upperCase() {
			return datum.toUpperCase();
		}
}
