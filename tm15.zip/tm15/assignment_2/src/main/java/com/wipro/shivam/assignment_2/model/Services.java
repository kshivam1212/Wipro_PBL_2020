

public class Services {
	
	private String serviceNames;

	public String getServiceNames() {
		return serviceNames;
	}

	public void setServiceNames(String serviceNames) {
		this.serviceNames = serviceNames;
	}

	public Services(String serviceNames) {
		super();
		this.serviceNames = serviceNames;
	}

	
	
}
