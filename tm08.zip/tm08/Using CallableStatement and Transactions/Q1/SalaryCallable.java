import java.sql.*;
class SalaryCallable{

    public static void main(String[] args){
	new calculateSalary(args);
    }
}
